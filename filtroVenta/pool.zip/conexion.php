<?php
/*Datos de conexion a la base de datos*/
$db_host = "localhost:3306";
$db_user = "root"; //grupoc20_test
$db_pass = ""; //M@}[?g^~9V[T
$db_name = "poos"; //grupoc20_testpos
 
$con = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
 
if(mysqli_connect_errno()){
	echo 'No se pudo conectar a la base de datos : '.mysqli_connect_error();
} else {
    //echo 'Listo';
}
?>
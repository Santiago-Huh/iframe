<div class="navbar navbar-inverse navbar-fixed-left">
  <ul class="nav navbar-nav" style="position: relative; left: 10px;">
  <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-user-friends"></i> <div>Contactos</div></a></li>
  <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-grip-horizontal"></i> <div>Productos</div></a></li>
  <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-grip-horizontal"></i> <div>Punto de venta</div></a></li>
   <li><a href="#">Link6</a></li>
   <li><a href="#">Link7</a></li>
   <li><a href="#">Link7</a></li>
   <li><a href="#">Link7</a></li>
   <li><a href="#">Link7</a></li>
   <li><a href="#">Link7</a></li>
   <li><a href="#">Link7</a></li>
  </ul>
</div>


<i class="far fa-vector-square"></i>
<div class="navbar navbar-inverse navbar-fixed-left">
  <ul class="nav navbar-nav" style="position: relative; left: 10px;">
  <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-user-friends"></i> <div>Contactos</div></a></li>
  <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-grip-horizontal"></i> <div>Productos</div></a></li>
  <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="far fa-credit-card"></i> <div>Punto de venta</div></a></li>
   <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-truck"></i> <div>&Oacute;rdenes de compra</div></a></li>
   <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-chart-pie"></i> <div>Reportes</div></a></li>
   <li class="active-side-bar active-hover"><a href="http://grupoconectate.com/dashboard" class=""><i style="font-size:25px;" class="fas fa-cog"></i> <div>Ajustes</div></a></li>
  </ul>
</div>


<i class="far fa-vector-square"></i>